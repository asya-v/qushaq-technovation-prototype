Qushaq Prototype

This is an interactive HTML/CSS/JavaScript prototype.

How to open:
1. Unzip the folder
2. Open index.html in Google Chrome

How to use:
- On first launch, complete the onboarding flow by entering demo child information
- The prototype saves entered data locally in the browser (localStorage)

Notes:
- No real login or backend is connected
- This is a front-end prototype for demonstration purposes